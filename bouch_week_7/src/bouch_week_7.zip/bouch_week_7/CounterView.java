/*
Damian Bouch
CIT 130
Week 7
Due: October 28, 2017
 */
//package bouch_week_7;

public class CounterView 
{
    public void Display(int counterValue)
    {
        System.out.println(counterValue);
    }
}
