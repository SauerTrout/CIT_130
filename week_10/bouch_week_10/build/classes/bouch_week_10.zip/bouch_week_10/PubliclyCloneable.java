/*
Damian Bouch
CIT 130 Week 10
Doubly Linked List
Due: December 2, 2017
 */
//package bouch_week_10;

public interface PubliclyCloneable extends Cloneable
{
    public Object clone();
}
