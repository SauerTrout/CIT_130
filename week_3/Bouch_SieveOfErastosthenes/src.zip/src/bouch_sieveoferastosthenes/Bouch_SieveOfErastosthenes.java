//Name: Damian Bouch
//Class: CIT 130
//Section: Z02B
//Week 3, Assignments 1 and 2
//package bouch_sieveoferastosthenes;
import java.util.Scanner;

public class Bouch_SieveOfErastosthenes {

    public static void main(String[] args) 
    {        
        SieveTest mySieveTest = new SieveTest();
        mySieveTest.SieveTest();
        
        FractionTest myFractionTest = new FractionTest();
        myFractionTest.FractionTest();
    }    
}
