//Name: Damian Bouch
//Class: CIT 130
//Section: Z02B
//Week 3, Assignment 1 
//Due: Sept 30, 2017


//package bouch_sieveoferastosthenes;

public class SieveTest 
{
    public void SieveTest()
    {     
        Sieve mySieve = new Sieve();
        
        mySieve.SieveSetOfNumbers();    
    }
}
